import React from 'react'

const MovablePart = ({moveablePropertiesOfList}) => {
    return (
        <div className='table-second-part'>
        <header className='dynamic-table-header'>
                {
                    Object.keys(moveablePropertiesOfList[0]).map((el,i)=>{
                        return <div className='dynamic-table-header-button' key={`table-header-${el}-${i}`}>{el}</div>
                    })
                }

            </header>
            <footer className='dynamic-colum-container'>
             {
               moveablePropertiesOfList.map((el,i) => {
                    return <div className='dynamic-table-colum' id={`fixed-table-colum-${i}`}>
                        {
                            Object.values(el,i).map((fixedItemValue) => {
                                return <div className='dynamic-table-value-button' key={`fixed-table-column-value-${el}-${i}`}>{fixedItemValue}</div>
                            })
                        }
                    </div>
                })
             }   
            </footer>
        </div>
    )
}

export default MovablePart
