import React, { useRef } from 'react'

const MovablePart = ({moveablePropertiesOfList}) => {
    let  divRef = useRef()
    const handleKeyDown = (e) => {
        const { key } = e;
        const divElement = divRef.current;
    
        if (key === 'ArrowLeft') {
          if (divElement) {
            divElement.scrollLeft -= 10; // Adjust the scroll speed as needed
          }
        } else if (key === 'ArrowRight') {
          if (divElement) {
            divElement.scrollLeft += 10; // Adjust the scroll speed as needed
          }
        }
      };
    
    
    return (
        <div className='table-second-part' onKeyDown={handleKeyDown}ref={ divRef }>
        <header className='dynamic-table-header'>
                {
                    Object?.keys(moveablePropertiesOfList[0])?.map((el,i)=>{
                        return <div className='dynamic-table-header-button' key={`table-header-${el}-${i}`}>{el}</div>
                    })
                }

            </header>
            <footer className='dynamic-colum-container'>
             {
               moveablePropertiesOfList?.map((el,i) => {
                    return <div className='dynamic-table-colum' id={`fixed-table-colum-${i}`}>
                        {
                            Object.values(el,i).map((fixedItemValue) => {
                                return <div className='dynamic-table-value-button' key={`fixed-table-column-value-${el}-${i}`}>{fixedItemValue}</div>
                            })
                        }
                    </div>
                })
             }   
            </footer>
        </div>
    )
}

export default MovablePart
