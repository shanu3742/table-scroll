import React from 'react'

const FixedPart = ({fixedPropertiesOfList}) => {
  return (
    <div className='table-first-part'>
    <header className='table-header'>
        {
            Object.keys(fixedPropertiesOfList[0]).map((el,i)=>{
                return <div className='table-header-button' key={`table-header-${el}-${i}`} style={{width:`${100/(Object.keys(fixedPropertiesOfList[0]).length)}%`}}>{el}</div>
            })
        }

    </header>
    <footer className='fixed-colum-container'>
     {
        fixedPropertiesOfList.map((el,i) => {
            return <div className='fixed-table-colum' id={`fixed-table-colum-${i}`}>
                {
                    Object.values(el,i).map((fixedItemValue) => {
                        return <div className='table-value-button' key={`fixed-table-column-value-${el}-${i}`} style={{width:`${100/(Object.values(el).length)}%`}}>{fixedItemValue}</div>
                    })
                }
            </div>
        })
     }   
    </footer>

</div>

  )
}

export default FixedPart