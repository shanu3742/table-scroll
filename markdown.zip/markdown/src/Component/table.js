import React from 'react'
import Tabledata from './rspone'
import './table.css'
import FixedPart from './FixedPart';
import MovablePart from './MovablePart';

const Table = () => {
    let response= Tabledata.result.data;

    //divide tableData into two part 

    /**
     * let's assume four properties is fixed and that is 
     * 1.Average
     * 2.Avg. Growth Rate (%)
     * 3.Metric
     * 4.d_region_name

     */
    let fixedPropertiesOfList = response.map((el,i) => {
        return {
            Average:el['Average'],
            'Avg. Growth Rate (%)':el['Avg. Growth Rate (%)'],
            Metric:el['Metric'],
            'd_region_name':el['d_region_name']
        }
    })

    let moveablePropertiesOfList = response.map((el,i) => {
        let {Average, "Avg. Growth Rate (%)":avg,"d_region_name":regionName ,Metric,...rest}=el;

        return {...rest}
    })

    console.log(fixedPropertiesOfList)
    console.log(moveablePropertiesOfList)
  return (
    <div className='table_container'>
       <FixedPart fixedPropertiesOfList={fixedPropertiesOfList} />

        <MovablePart moveablePropertiesOfList={moveablePropertiesOfList} />
    </div>
  )
}

export default Table