import React, { useState } from 'react'
import Tabledata from './rspone'
import './table.css'
import FixedPart from './FixedPart';
import MovablePart from './MovablePart';

const Table = () => {

    
    let response= Tabledata.result.data;

    //divide tableData into two part 

    /**
     * let's assume four properties is fixed and that is 
     * 1.Average
     * 2.Avg. Growth Rate (%)
     * 3.Metric
     * 4.d_region_name

     */
    const [tableData,setTableData]=useState(response)
    const [selectedOption, setSelectedOption] = useState('10');
    const [pageNumber,setPageNumber] = useState(0)
   

    const [totalPage,setTotalPage]= useState(0)
    const handleChange = (event) => {
      setSelectedOption(event.target.value);
    };

    React.useEffect(() => {
let result = response.filter((el,i) => {
  let statring = pageNumber*(+selectedOption);
  let ending= statring+(+selectedOption)
  if(statring<=i && ending>i){
    return true
  }else{
    return false
  }
})

let pages= Math.ceil(response.length/ (+selectedOption));
setTotalPage(pages)
setTableData(result)
    },[pageNumber, response, selectedOption])

    let fixedPropertiesOfList =  tableData?.map((el) => {
      return {
        'Enterprise Partner Name':el['Enterprise Partner Name'],
        'Rank #':el['Rank #'],
        'Part #':el['Part #'],
        'Title':el['Title']
      }
    })

  


    let moveablePropertiesOfList = tableData?.map((el) => {
      let {'Enterprise Partner Name':EnterprisePartnerName,'Rank #':rank,'Part #':part,'Title':title,...rest} =el
      return {...rest}
    })


  
const increasePage = () => {
  if(pageNumber+1<totalPage){
    setPageNumber((p) => p+1)
  }else{
    return
  }
}
const DecrementPage = () => {
  if(pageNumber>0){
    setPageNumber((p) => p-1)
  }else{
    return
  }
}
const increaseForwardPage= () => {
  if(pageNumber+2<totalPage){
    setPageNumber((p) => p+2)
  }else{
    return
  }

}
const decrementForwardPage= () => {
  if(pageNumber>1){
    setPageNumber((p) => p-2)
  }else{
    return
  }

}
let doubleDecremetIcon=`<<`
let doubleIncrementIcon='>>'
  return (
   <div>
    {
      fixedPropertiesOfList && moveablePropertiesOfList &&  <div className='table_container'>
      <FixedPart fixedPropertiesOfList={fixedPropertiesOfList} />

       <MovablePart moveablePropertiesOfList={moveablePropertiesOfList} />
   </div>
    }
    <div className='table-pagination'>
    <div>
      
      <select value={selectedOption} onChange={handleChange}>
        <option value="">Select an option</option>
        <option value="10">10</option>
        <option value="11">11</option>
        <option value="13">13</option>
        <option value="15">15</option>
        <option value="18">18</option>
        <option value="20">20</option>
      </select>
      
    </div>

    <div className='navigation-container'>
      <div onClick={ decrementForwardPage} className={`navigation-button  ${pageNumber>1?'enableButton':'disableButton'}`}>{doubleDecremetIcon}</div>
      <div onClick={DecrementPage}  className={`navigation-button ${pageNumber>0?'enableButton':'disableButton'}` }>◀</div>
      <div className='page-display'><span className={`navigation-button`}>{pageNumber+1}</span>of <span>{totalPage}</span></div>
      <div onClick={increasePage}  className={`navigation-button  ${pageNumber+1<totalPage?'enableButton':'disableButton'}`} >▶</div>
      <div onClick={increaseForwardPage}  className={`navigation-button  ${pageNumber+2<totalPage?'enableButton':'disableButton'}`}>{doubleIncrementIcon}</div>
    </div>
    </div>


   </div>
  )
}

export default Table
