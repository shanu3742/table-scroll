import React from 'react'
import style from './headerImage.module.css'
import { Button } from 'rsuite'

const HeaderImage = ({avtar}) => {
  return (
   
    <header
    className={style[`img-header-container`]}
    style={{
      backgroundImage: `url(${avtar})`,
    }}
  >
    <span className={style[`logo-center-container`]}><img src='https://bolgground.co.in/static/media/B%20(3)%20(1).a5536f50d255af69372fb89a940135eb.svg' alt='blog ground img' width={100}/></span>
   <div className={'upload-button-container'}>
   <Button />
   </div>
  </header>
  )
}

export default HeaderImage