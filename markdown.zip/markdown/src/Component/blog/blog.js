import React, { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { BsCalendarEvent, BsPersonCircle, BsListUl } from "react-icons/bs";
import ArowBackIcon from "@rsuite/icons/ArowBack";
import "./cricket.css";
import { BsStopwatch } from "react-icons/bs";
import MarkDownHeadingEditor from "../../MarkdownHeading/MarkDownHeadingEditior";
import MarkDownNavigationEditior from "../../MarkDownNavigation/MarkDownNavigation";
import avtar from '../../avatar-svgrepo-com.svg'
import { Avatar } from "rsuite";
import MarkDownPragraph from "../../MarkDownPragraph/MarkDownPragraph";
import HeaderImage from "../blogImage/headerImage";

const CricketView = () => {
  //   console.log(timeTillSecond);
  //   console.log(timeArray);

  // console.log('home town purnea'.substring(0, 5));

  //all navigation from here
  const navigate = useNavigate();
  const onBackButtonPressed = () => {
    navigate("/");
  };
  // console.log(BlogDetails?.createdAt);

  /**navigation point */

  const [navigationLisit, setNavigtaionList] = useState(JSON.parse(localStorage.getItem('navigationList')) ===null?[]:JSON.parse(localStorage.getItem('navigationList')));
  const [blogHeading, setBlogHeading] = useState("edit heading");
  const [navigateTo, setNavigateTo] = useState(0);
  const [newNavigation,setNewNavigation] = useState(true)
  const addNewNavigation = () => {
    setNewNavigation(true)
    console.log(navigationLisit)
    setNavigtaionList((p) => {
      return [
        ...p,
        {
          id: `${navigateTo}`,
          value: blogHeading,
        },
      ];
    });
    setBlogHeading('edit heading')
    localStorage.setItem('navigationList',JSON.stringify(navigationLisit))
  };
  const submitNavigation = () => {
    setNavigtaionList((p) => {
      return [
        ...p,
        {
          id: `${navigateTo}`,
          value: blogHeading,
        },
      ];
    });
    setBlogHeading('edit heading')
    localStorage.setItem('navigationList',JSON.stringify(navigationLisit))
    setNewNavigation(false)
  }
  /**********************************blog paragraph */
  const [blogPragraphList,setBlogPragraphList] = useState(JSON.parse(localStorage.getItem('pragraphList'))??[])
  console.log('ine',blogPragraphList)
  const [blogParagraph, setBlogParagraph] = useState("edit paragraph");
  const [newParagraph, setNewParagraph] = useState(true)
  const addNewParagraph = () => {
    setNewParagraph(true)
    console.log(navigationLisit)
    setBlogPragraphList((p) => {
      return [
        ...p,
        {
          id: `${blogPragraphList.length+1}`,
          value: blogParagraph,
        },
      ];
    });
    setBlogParagraph('edit paragraph')
    localStorage.setItem('pragraphList',JSON.stringify(blogPragraphList)) 
  }

  const submitParagraph = () => {
    setBlogPragraphList((p) => {
      return [
        ...p,
        {
          id: `${blogPragraphList.length}`,
          value: blogParagraph,
        },
      ];
    });
    setBlogParagraph('edit paragraph')
    localStorage.setItem('pragraphList',JSON.stringify(blogPragraphList))
    setNewParagraph(false)
  }
  return (
    <div className="cricket-view">
      <>
        <nav className="backButton-cricket-view" onClick={onBackButtonPressed}>
          <div>
            <ArowBackIcon />
          </div>
          <div className="backIcon">
            <b>Go BACK</b>
          </div>
        </nav>
         <HeaderImage avtar={Avatar} />
        <footer className="sidebar-footer">
          {/* center right-sidebar start here */}
          <div className="right-sidebar">
            <div className="s-layout__sidebar">
              <nav className="s-sidebar__nav">share button</nav>
            </div>
          </div>
          {/* center container start here */}
          <div className="center-container">
            <header>
              <h1>All about Cricket</h1>
              <div className="batch-container">
                <div className="batch-container-inside">
                  <div title="icon">
                    <BsPersonCircle />
                  </div>
                  <h6 className="center-title" style={{ color: "gray" }}>
                    "Not Editeable"
                  </h6>
                </div>
                <div className="batch-container-inside">
                  <div title="icon">
                    <BsCalendarEvent />
                  </div>

                  <h6 className="center-title">Not Editeable</h6>
                </div>
                <div className="batch-container-inside">
                  <div title="icon">
                    <BsStopwatch />
                  </div>
                  <h6 className="center-title">Not Editeable</h6>
                </div>
              </div>
              {/* /here table important point started */}
              <div className="pitch-table-container">
                <div>
                  <div title="icon">
                    <BsListUl />
                  </div>
                  <h2 className="pitch-table-container-title">
                    Key Points Of Content
                  </h2>
                </div>
                <nav className="app-pitch-with-li-ul-container">
                  {navigationLisit?.length > 0 && (
                    <>
                      {navigationLisit.map((navigationItem,navigationIndex) => {
                        return (
                          <div style={{ color: "white", textDecoration: "none",width:'100%' }}>

                      <a href={`#${navigationItem.id}`} style={{ color: "white", textDecoration: "none" }}>
                            <div
                              className={`app-pitch-with-li-ul app-pitch-with-li-ul-${0}`}
                            >
                              <div className="box1">
                                <MarkDownNavigationEditior
                                  contentisEditeable={false}
                                  blogHeading={navigationItem.value}
                                  selectedButton={navigationIndex}
                                />
                              </div>
                            </div>
                          </a>
                          
                          </div>
                        
                        );
                      })}
                    </>
                  )}
               {
                newNavigation &&   <div style={{width:'100%'}}>
                <a style={{ color: "white", textDecoration: "none" }}>
                   <div
                     className={`app-pitch-with-li-ul app-pitch-with-li-ul-${0}`}
                   >
                     <div className="box1">
                       <MarkDownNavigationEditior
                         contentisEditeable={true}
                         blogHeading={blogHeading}
                         setBlogHeading={setBlogHeading}
                         navigateTo={navigateTo}
                         setNavigateTo={setNavigateTo}
                       />

                     </div>
                   </div>
                 </a>
                 <button onClick={addNewNavigation}>Add</button> 
                 <button onClick={submitNavigation}>submit</button> 
                </div>
               }
                </nav>
              </div>
            </header>

            <section className="blog-content-container">
              <div className="centet-blog-details">
                <header>
                  <MarkDownHeadingEditor contentisEditeable={true} />
                </header>

                <section className="paragraph-container">
                 
                <div>
                  <div>
                  {blogPragraphList?.length > 0 && (
                    <>
                      {blogPragraphList.map((blogPragraphItem,blogPragraphIndex) => {
                        return (
                          <div style={{ color: "white", textDecoration: "none",width:'100%' }} id={`${blogPragraphIndex+1}`}>

                      <a style={{ color: "white", textDecoration: "none" }}>
                            <div
                              className={`paragraph-conatiner-data`}
                            >
                              <h6>{navigationLisit[blogPragraphIndex].value}</h6>
                              <div className="box1">
                                <MarkDownPragraph
                                  contentisEditeable={false}
                                  blogParagraph={blogPragraphItem.value}
                                  selectedButton={blogPragraphIndex}
                                />
                              </div>
                            </div>
                          </a>
                          
                          </div>
                        
                        );
                      })}
                    </>
                  )}
                  </div>
                {
                  newParagraph &&  <div>
                  <MarkDownPragraph contentisEditeable={true} blogParagraph={blogParagraph} setBlogParagraph={setBlogParagraph} />
                  <button onClick={addNewParagraph}>Add</button> 
                  <button onClick={submitParagraph}>submit</button> 
                  </div>
                 }
                </div>
                  {/* here code snippet will be ther  */}
                </section>
                <footer className="prg-footer-container">
                  <p>shanu kumar</p>
                </footer>
              </div>
            </section>
          </div>
          {/* end here center */}
          <div className="left-sidebar">sjanu</div>
        </footer>
      </>
    </div>
  );
};

export default CricketView;
