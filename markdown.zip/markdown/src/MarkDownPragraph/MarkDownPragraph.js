import React, { useState } from "react";
import ReactMarkdown from "react-markdown";
import rehypeRaw from "rehype-raw";
import style from "./MarkDownPragraph.module.css";
import rehypeHighlight from 'rehype-highlight'
import {
  Button,
  Tooltip,
  ButtonGroup,
  IconButton,
  Whisper,
  Input,
} from "rsuite";
import BoldIcon from "@rsuite/icons/legacy/Bold";
import ItalicIcon from "@rsuite/icons/legacy/Italic";
import UnderlineIcon from "@rsuite/icons/legacy/Underline";
import StrikethroughIcon from "@rsuite/icons/legacy/Strikethrough";
import { TfiParagraph } from "react-icons/tfi";
import { Modal } from "rsuite";
import { AiOutlineBgColors } from "react-icons/ai";
import remarkGfm from "remark-gfm";
import EditIcon from "@rsuite/icons/Edit";
import CloseOutlineIcon from "@rsuite/icons/CloseOutline";
import AlignLeftIcon from "@rsuite/icons/legacy/AlignLeft";
import AlignCenterIcon from "@rsuite/icons/legacy/AlignCenter";
import AlignRightIcon from "@rsuite/icons/legacy/AlignRight";
import AlignJustifyIcon from "@rsuite/icons/legacy/AlignJustify";
import InfoRoundIcon from '@rsuite/icons/InfoRound';
import {Prism as SyntaxHighlighter} from 'react-syntax-highlighter';
import {dark} from 'react-syntax-highlighter/dist/esm/styles/prism'
import TableColumnIcon from '@rsuite/icons/TableColumn';
import ListIcon from '@rsuite/icons/List';
import {SiQuora }from 'react-icons/si'
import ImageIcon from '@rsuite/icons/Image';
const MarkDownPragraph = ({ contentisEditeable = false ,blogParagraph,setBlogParagraph,selectedButton}) => {
  //     # H1
  // ## H2
  // ### H3
  // #### H4
  // ##### H5
  // ###### H6
  const tooltip = (value) => {
    return <Tooltip>{value}</Tooltip>;
  };

  const [editHeading, setEditHeading] = useState(false);
  const [open, setOpen] = React.useState(false);
  const [textopen, setTextOpen] = React.useState(false);
 
  const handleTextOpen = (value) => {
    setTextOpen(true);
  };
  const handleTextClose = () => {
    setTextOpen(false);
  };
  

  const onMarker = () => {
    //first get the text and then mark it
    console.log("hello");
    navigator.clipboard
      .readText()
      .then((text) => {
        if (text === "") {
          return;
        }
        console.log(text);
        setBlogParagraph((p) =>
       p.replace(text, `<mark>${text} </mark>`)
        );
       
        navigator.clipboard.writeText("").then(
          function () {
            console.log("Async: Copying to clipboard was successful!");
          },
          function (err) {
            console.error("Async: Could not copy text: ", err);
          }
        );
      })
      .catch((err) => {
        console.error("Failed to read clipboard contents: ", err);
      });
    //   after it clear the cleapboart
  };

  const onBoald = () => {
    navigator.clipboard
      .readText()
      .then((text) => {
        if (text === "") {
          return;
        }
        setBlogParagraph((p) =>p.replace(text, `**${text}**`));

        navigator.clipboard.writeText("").then(
          function () {
            console.log("Async: Copying to clipboard was successful!");
          },
          function (err) {
            console.error("Async: Could not copy text: ", err);
          }
        );
      })
      .catch((err) => {
        console.error("Failed to read clipboard contents: ", err);
      });
    //   after it clear the cleapboart
  };
  const onitalic = () => {
    navigator.clipboard
      .readText()
      .then((text) => {
        if (text === "") {
          return;
        }
        setBlogParagraph((p) =>p.replace(text, `*${text}*`));

        navigator.clipboard.writeText("").then(
          function () {
            console.log("Async: Copying to clipboard was successful!");
          },
          function (err) {
            console.error("Async: Could not copy text: ", err);
          }
        );
      })
      .catch((err) => {
        console.error("Failed to read clipboard contents: ", err);
      });
    //   after it clear the cleapboart
  };
  const onUnderLine = () => {
    navigator.clipboard
      .readText()
      .then((text) => {
        if (text === "") {
          return;
        }
        setBlogParagraph((p) =>p.replace(text, `<u>${text}</u>`));

        navigator.clipboard.writeText("").then(
          function () {
            console.log("Async: Copying to clipboard was successful!");
          },
          function (err) {
            console.error("Async: Could not copy text: ", err);
          }
        );
      })
      .catch((err) => {
        console.error("Failed to read clipboard contents: ", err);
      });
    //   after it clear the cleapboart
  };
  const onOverLine = () => {
    navigator.clipboard
      .readText()
      .then((text) => {
        if (text === "") {
          return;
        }
        setBlogParagraph((p) =>p.replace(text, `~~${text}~~`));

        navigator.clipboard.writeText("").then(
          function () {
            console.log("Async: Copying to clipboard was successful!");
          },
          function (err) {
            console.error("Async: Could not copy text: ", err);
          }
        );
      })
      .catch((err) => {
        console.error("Failed to read clipboard contents: ", err);
      });
    //   after it clear the cleapboart
  };
  const onEditing = () => {
    setEditHeading(true);
  };
  const onInputUpdate = (value) => {
    setBlogParagraph(value);
  };
  const [alignment, setAlignment] = useState("left");
const selectLang = (langType) => {
  
   

    setBlogParagraph((p) => p+ `   \n ${langType} \n edit code here   `+'   \n```');
    
    setTextOpen('true')

}

const openTable = () => {
  setBlogParagraph((p) => p+ '\n | edit keyOne  | edit keyTwo |  \n |-------|------| \n | edit valueOne | edit valueTwo | \n');
  setTextOpen('true')
}
const openList = () => {
  setBlogParagraph((p) => p+ '\n - edit list one \n - edit list two \n - edit list three \n ');
  setTextOpen('true')
}
const getQuotes = () => {
  setBlogParagraph((p) => p+ '\n > edit note here');
  setTextOpen('true')
}
const [imageopen,setImageOpen] = useState(false)
const addImageTomarkDown = () => {
 setImageOpen(true)
}
const onbuttonSelected = (value='>') => {
  setBlogParagraph((p) => p+ '\n ![markdown-image'+value+'](https://cdn.pixabay.com/photo/2023/03/22/02/02/skier-7868502_960_720.png?size=200)  \n')
  setImageOpen(false)
}

const handleImageClose = () => {
  setOpen(true)
}
React.useEffect(() => {
  //if image is added using markdown then we have to catch the image width form optional parameter of url and set it  
document.querySelectorAll('[alt="markdown-image<"]')?.forEach((e) => {
  let width= e.getAttribute('src').split('?size=')[1]
  e.setAttribute('width',`${width}px`)
})
document.querySelectorAll('[alt="markdown-image>"]')?.forEach((e) => {
  let width= e.getAttribute('src').split('?size=')[1]
  e.setAttribute('width',`${width}px`)
})
document.querySelectorAll('[alt="markdown-image><"]')?.forEach((e) => {
  let width= e.getAttribute('src').split('?size=')[1]
  e.setAttribute('width',`${width}px`)
})
 
})

//  ![alt text](https://cdn.pixabay.com/photo/2023/03/22/02/02/skier-7868502_960_720.png)
  return (
    <div
      className={
        !editHeading
          ? style["headingContainer-without-edit"]
          : style["headingContainer"]
      }
    >
      {selectedButton ===undefined && <>
        {!editHeading && contentisEditeable ? (
        <div className={style["edit-icon"]} onClick={onEditing}>
          <EditIcon color="red" />
        </div>
      ) : (
        <div className={style["edit-icon"]}>
          <div>
            <ButtonGroup>
            <Modal size={"md"} open={imageopen} onClose={handleImageClose}>
                <Modal.Header>
                  <Modal.Title>
                    <h6>image position</h6>
                   
                  </Modal.Title>
                </Modal.Header>
                <Modal.Body>
               
                 <ButtonGroup>
                 <Button  onClick={() => onbuttonSelected('<')}>left</Button>                
                  <Button onClick={() => onbuttonSelected('><')}>center</Button>
                  <Button onClick={() => onbuttonSelected('>')}>right</Button>
                 
                 </ButtonGroup>
                </Modal.Body>
                <Modal.Footer>
                 
                </Modal.Footer>
              </Modal>
              <Modal size={"md"} open={textopen} onClose={handleTextClose}>
                <Modal.Header>
                  <Modal.Title>
                    <h6>Edit paragraph</h6>
                    <div className={style['info-container']}>
                        <InfoRoundIcon  color="red"/>
                        <p>if you want to enter in new line please add two space after ending of your current editing  line</p>
                    </div>
                  </Modal.Title>
                </Modal.Header>
                <Modal.Body>
               
                  <Input
                   as="textarea"
                   rows={3} placeholder="Textarea" 
                    value={blogParagraph}
                    onChange={(e) => onInputUpdate(e)}
                  />
                </Modal.Body>
                <Modal.Footer>
                  <Button onClick={handleTextClose}>close</Button>
                </Modal.Footer>
              </Modal>
              <Button onClick={handleTextOpen}>Edit Text</Button>
              <IconButton icon={<TfiParagraph />} />
              <ButtonGroup>
                    <Button onClick={() => selectLang('```javascript')}>javascript</Button>
                    <Button onClick={() => selectLang('```c')}>c</Button>
                    <Button onClick={() => selectLang('```python')}>python</Button>
                    <Button onClick={() => selectLang('```html')}>html</Button>
                    <Button onClick={() => selectLang('```css')}>css</Button>
                    <Button onClick={() => selectLang('```java')}>java</Button>
            </ButtonGroup>
              <Whisper
                placement="bottom"
                controlId="control-id-hover"
                trigger="hover"
                speaker={tooltip("copy the text first to make it Bold")}
              >
                <IconButton icon={<BoldIcon onClick={onBoald} />} />
              </Whisper>
              <Whisper
                placement="bottom"
                controlId="control-id-hover"
                trigger="hover"
                speaker={tooltip("copy the text first to make it italic")}
              >
                <IconButton onClick={onitalic} icon={<ItalicIcon />} />
              </Whisper>
              <Whisper
                placement="bottom"
                controlId="control-id-hover"
                trigger="hover"
                speaker={tooltip("copy the text first to make it underline")}
              >
                <IconButton onClick={onUnderLine} icon={<UnderlineIcon />} />
              </Whisper>
              <Whisper
                placement="bottom"
                controlId="control-id-hover"
                trigger="hover"
                speaker={tooltip("copy the text first to make it overline")}
              >
                <IconButton onClick={onOverLine} icon={<StrikethroughIcon />} />
              </Whisper>
              <Whisper
                placement="bottom"
                controlId="control-id-hover"
                trigger="hover"
                speaker={tooltip(
                  "copy the text first to make it heightlighted"
                )}
              >
                <IconButton icon={<AiOutlineBgColors />} onClick={onMarker} />
              </Whisper>
            </ButtonGroup>
            <ButtonGroup>
            <IconButton
                icon={<ImageIcon />}
                onClick={addImageTomarkDown}
              />
            <IconButton
                icon={<AlignLeftIcon />}
                onClick={() => setAlignment("left")}
              />
           
              
              <IconButton
                icon={<AlignCenterIcon />}
                onClick={() => setAlignment("center")}
              />
              <IconButton
                icon={<AlignRightIcon />}
                onClick={() => setAlignment("right")}
              />
              <IconButton
                icon={<AlignJustifyIcon />}
                onClick={() => setAlignment("justify")}
              />
              <IconButton
                icon={<TableColumnIcon />}
                onClick={openTable}
              />
                <IconButton
                icon={<ListIcon/>}
                onClick={openList}
              />
              <IconButton
                icon={<SiQuora/>}
                onClick={getQuotes}
              />
              {/* ListIcon */}
               {/* TableColumnIcon */}
            </ButtonGroup>
          </div>
          <div onClick={() => setEditHeading(false)}>
            {" "}
            <IconButton icon={<CloseOutlineIcon color="red" />} />
          </div>
        </div>
      )}
      </> }
     
      <div id='markdown-box'
        className={style[`text-${alignment}`]}
        onInput={(e) => setBlogParagraph(e.currentTarget.textContent)}
      >
        <ReactMarkdown
        
          remarkPlugins={[[remarkGfm, { singleTilde: false }]]}
          children={`${blogParagraph}`}
          rehypePlugins={[rehypeRaw]}
          components={{
            code({node, inline, className, children, ...props}) {
              const match = /language-(\w+)/.exec(className || '')
              return !inline && match ? (
                <SyntaxHighlighter
                  children={String(children).replace(/\n$/, '')}
                  style={dark}
                  language={match[1]}
                  PreTag="div"
                  {...props}
                />
              ) : (
                <code className={className} {...props}>
                  {children}
                </code>
              )
            }
          }}
        ></ReactMarkdown>
      </div>
    </div>
  )
}


export default MarkDownPragraph 
