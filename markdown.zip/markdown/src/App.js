import logo from "./logo.svg";
import "./App.css";
import MarkDownHeadingEditor from "./MarkdownHeading/MarkDownHeadingEditior.js";
import { Routes, Route } from "react-router-dom";
import CricketView from "./Component/blog/blog";
import MarkDownPragraph from "./MarkDownPragraph/MarkDownPragraph";
import Table from "./Component/table";

const  App = () => {
  //  <MarkDownHeadingEditor contentisEditeable="false" />;

  return (
    <div>
      <Routes>
        {/* <Route
          path="/"
          element={<MarkDownPragraph contentisEditeable={true} />}
        /> */}
        {/* <Route
          path="/home"
          element={<MarkDownHeadingEditor contentisEditeable="false" />}
        /> */}
        {/* <Route
          path="/"
          element={<MarkDownHeadingEditor contentisEditeable={true} />}
        /> */}
        <Route path="/" element={<Table />} />
      </Routes>
    </div>
  );
}
export default App;