import React, { useState } from "react";
import ReactMarkdown from "react-markdown";
import rehypeRaw from "rehype-raw";
import style from "./MarkDownNavigation.module.css";
import {
  Button,
  Tooltip,
  ButtonGroup,
  IconButton,
  Whisper,
  Input,
} from "rsuite";
import FileTextIcon from "@rsuite/icons/legacy/FileText";
import SaveIcon from "@rsuite/icons/legacy/Save";
import BoldIcon from "@rsuite/icons/legacy/Bold";
import ItalicIcon from "@rsuite/icons/legacy/Italic";
import UnderlineIcon from "@rsuite/icons/legacy/Underline";
import StrikethroughIcon from "@rsuite/icons/legacy/Strikethrough";
import { TfiParagraph } from "react-icons/tfi";
import { Modal, Placeholder } from "rsuite";
import { AiOutlineBgColors } from "react-icons/ai";
import remarkGfm from "remark-gfm";
import EditIcon from "@rsuite/icons/Edit";
import CloseOutlineIcon from "@rsuite/icons/CloseOutline";
import AlignLeftIcon from "@rsuite/icons/legacy/AlignLeft";
import AlignCenterIcon from "@rsuite/icons/legacy/AlignCenter";
import AlignRightIcon from "@rsuite/icons/legacy/AlignRight";
import AlignJustifyIcon from "@rsuite/icons/legacy/AlignJustify";

const MarkDownNavigationEditior = ({
  contentisEditeable = false,
  blogHeading,
  setBlogHeading,
  navigateTo,
  setNavigateTo,
  selectedButton
}) => {
  //     # H1
  // ## H2
  // ### H3
  // #### H4
  // ##### H5
  // ###### H6
  // let keyPoint = {
  //   id: inuptNumber,
  //   value: inuptKeyPont,
  // };
  const tooltip = (value) => {
    return <Tooltip>{value}</Tooltip>;
  };

  const [editHeading, setEditHeading] = useState(false);
  const [open, setOpen] = React.useState(false);
  const [textopen, setTextOpen] = React.useState(false);
  const handleOpen = (value) => {
    setOpen(true);
  };
  const handleTextOpen = (value) => {
    setTextOpen(true);
  };
  const handleClose = () => setOpen(false);

  const handleTextClose = () => {
    setTextOpen(false);
  };


  const onMarker = () => {
    //first get the text and then mark it
    console.log("hello");
    navigator.clipboard
      .readText()
      .then((text) => {
        if (text === "") {
          return;
        }
        console.log(text);
        setBlogHeading((p) =>
          p.replace(text, `<mark>${text} </mark>`)
        );
        console.log(blogHeading);
        navigator.clipboard.writeText("").then(
          function () {
            console.log("Async: Copying to clipboard was successful!");
          },
          function (err) {
            console.error("Async: Could not copy text: ", err);
          }
        );
      })
      .catch((err) => {
        console.error("Failed to read clipboard contents: ", err);
      });
    //   after it clear the cleapboart
  };

  const onBoald = () => {
    navigator.clipboard
      .readText()
      .then((text) => {
        if (text === "") {
          return;
        }
        setBlogHeading((p) => p.replace(text, `**${text}**`));

        navigator.clipboard.writeText("").then(
          function () {
            console.log("Async: Copying to clipboard was successful!");
          },
          function (err) {
            console.error("Async: Could not copy text: ", err);
          }
        );
      })
      .catch((err) => {
        console.error("Failed to read clipboard contents: ", err);
      });
    //   after it clear the cleapboart
  };
  const onitalic = () => {
    navigator.clipboard
      .readText()
      .then((text) => {
        if (text === "") {
          return;
        }
        setBlogHeading((p) => p.replace(text, `*${text}*`));

        navigator.clipboard.writeText("").then(
          function () {
            console.log("Async: Copying to clipboard was successful!");
          },
          function (err) {
            console.error("Async: Could not copy text: ", err);
          }
        );
      })
      .catch((err) => {
        console.error("Failed to read clipboard contents: ", err);
      });
    //   after it clear the cleapboart
  };
  const onUnderLine = () => {
    navigator.clipboard
      .readText()
      .then((text) => {
        if (text === "") {
          return;
        }
        setBlogHeading((p) => p.replace(text, `<u>${text}</u>`));

        navigator.clipboard.writeText("").then(
          function () {
            console.log("Async: Copying to clipboard was successful!");
          },
          function (err) {
            console.error("Async: Could not copy text: ", err);
          }
        );
      })
      .catch((err) => {
        console.error("Failed to read clipboard contents: ", err);
      });
    //   after it clear the cleapboart
  };
  const onOverLine = () => {
    navigator.clipboard
      .readText()
      .then((text) => {
        if (text === "") {
          return;
        }
        setBlogHeading((p) => p.replace(text, `~~${text}~~`));

        navigator.clipboard.writeText("").then(
          function () {
            console.log("Async: Copying to clipboard was successful!");
          },
          function (err) {
            console.error("Async: Could not copy text: ", err);
          }
        );
      })
      .catch((err) => {
        console.error("Failed to read clipboard contents: ", err);
      });
    //   after it clear the cleapboart
  };
  const onEditing = () => {
    setEditHeading(true);
  };
  const onInputUpdate = (value) => {
    setBlogHeading(value);
  };
  const [alignment, setAlignment] = useState("left");

  return (
    <div
      className={
        !editHeading
          ? style["headingContainer-without-edit"]
          : style["headingContainer"]
      }
    >
     {
      selectedButton ===undefined  && <>
       {!editHeading && contentisEditeable ? (
        <div className={style["edit-icon"]} onClick={onEditing}>
          <EditIcon color="white" />
        </div>
      ) : (
        <div className={style["edit-icon"]}>
          <div>
            <ButtonGroup>
              <Modal size={"xs"} open={textopen} onClose={handleTextClose}>
                <Modal.Header>
                  <Modal.Title>Enter Navigation name</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                <Input
          type="number"
          value={navigateTo}
          onChange={(e) => setNavigateTo(e)}
        />
                  <Input
                    value={blogHeading}
                    onChange={(e) => onInputUpdate(e)}
                  />
                </Modal.Body>
                <Modal.Footer>
                  <Button onClick={handleTextClose}>close</Button>
                </Modal.Footer>
              </Modal>
              <Button onClick={handleTextOpen}>Edit Text</Button>
              <IconButton icon={<TfiParagraph />} />
              <Whisper
                placement="bottom"
                controlId="control-id-hover"
                trigger="hover"
                speaker={tooltip("copy the text first to make it Bold")}
              >
                <IconButton icon={<BoldIcon onClick={onBoald} />} />
              </Whisper>
              <Whisper
                placement="bottom"
                controlId="control-id-hover"
                trigger="hover"
                speaker={tooltip("copy the text first to make it italic")}
              >
                <IconButton onClick={onitalic} icon={<ItalicIcon />} />
              </Whisper>
              <Whisper
                placement="bottom"
                controlId="control-id-hover"
                trigger="hover"
                speaker={tooltip("copy the text first to make it underline")}
              >
                <IconButton onClick={onUnderLine} icon={<UnderlineIcon />} />
              </Whisper>
              <Whisper
                placement="bottom"
                controlId="control-id-hover"
                trigger="hover"
                speaker={tooltip("copy the text first to make it overline")}
              >
                <IconButton onClick={onOverLine} icon={<StrikethroughIcon />} />
              </Whisper>
              <Whisper
                placement="bottom"
                controlId="control-id-hover"
                trigger="hover"
                speaker={tooltip(
                  "copy the text first to make it heightlighted"
                )}
              >
                <IconButton icon={<AiOutlineBgColors />} onClick={onMarker} />
              </Whisper>
            </ButtonGroup>
            <ButtonGroup>
              <IconButton
                icon={<AlignLeftIcon />}
                onClick={() => setAlignment("left")}
              />
              <IconButton
                icon={<AlignCenterIcon />}
                onClick={() => setAlignment("center")}
              />
              <IconButton
                icon={<AlignRightIcon />}
                onClick={() => setAlignment("right")}
              />
              <IconButton
                icon={<AlignJustifyIcon />}
                onClick={() => setAlignment("justify")}
              />
            </ButtonGroup>
          </div>
          <div onClick={() => setEditHeading(false)}>
            {" "}
            <IconButton icon={<CloseOutlineIcon color="red" />} />
          </div>
        </div>
      )}</>
     }
      <div>
        
      </div>
      <div
        className={style[`text-${alignment}`]}
        onInput={(e) => setBlogHeading(e.currentTarget.textContent)}
      >
        <ReactMarkdown
          remarkPlugins={[[remarkGfm, { singleTilde: false }]]}
          children={`${blogHeading}`}
          rehypePlugins={[rehypeRaw]}
        ></ReactMarkdown>
      </div>
    </div>
  );
};

export default MarkDownNavigationEditior;
